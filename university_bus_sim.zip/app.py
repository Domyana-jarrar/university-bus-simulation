import streamlit as st
import simpy
import random
import matplotlib.pyplot as plt

RANDOM_SEED = 42
NUM_STUDENTS = st.slider("Number of Students", 10, 200, 100)
BUS_CAPACITY = st.slider("Bus Capacity", 5, 50, 20)
INTER_ARRIVAL_TIME = st.slider("Student Arrival Interval", 1, 10, 1)
BUS_INTERVAL = st.slider("Bus Interval", 5, 30, 10)
SIM_DURATION = st.slider("Simulation Duration", 50, 300, 100)

wait_times = []
students_left = 0
bus_schedule = []

def student(env, name, bus_stop, arrival_time, result_list):
    with bus_stop.request() as request:
        yield request
        wait = env.now - arrival_time
        result_list.append((int(name.split()[1]), wait))

def bus_arrival(env, bus_stop):
    global students_left
    while True:
        yield env.timeout(BUS_INTERVAL)
        served = 0
        while served < BUS_CAPACITY and len(queue) > 0:
            student_proc, arrival_time, student_name = queue.pop(0)
            env.process(student(env, student_name, bus_stop, arrival_time, wait_times))
            served += 1
        students_left += len(queue)
        queue.clear()

def setup(env):
    global queue
    queue = []
    env.process(bus_arrival(env, bus_stop))
    for i in range(NUM_STUDENTS):
        yield env.timeout(random.expovariate(1.0 / INTER_ARRIVAL_TIME))
        arrival_time = env.now
        queue.append((student, arrival_time, f'Student {i}'))

if st.button("Run Simulation"):
    random.seed(RANDOM_SEED)
    env = simpy.Environment()
    bus_stop = simpy.Resource(env, capacity=1)
    env.process(setup(env))
    env.run(until=SIM_DURATION)

    wait_times.sort(key=lambda x: x[0])
    first_50 = wait_times[:50]
    students = [s[0] for s in first_50]
    waits = [s[1] for s in first_50]

    fig, ax = plt.subplots(figsize=(10, 4))
    ax.bar(students, waits, color='skyblue')
    ax.set_title("Sample Wait Times - First 50 Students")
    ax.set_xlabel("Student")
    ax.set_ylabel("Wait Time (seconds)")
    ax.grid(True, axis='y')
    st.pyplot(fig)

    st.markdown(f"**Number of students who boarded:** {len(wait_times)}")
    st.markdown(f"**Number of students left behind:** {students_left}")